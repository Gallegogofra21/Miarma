package com.salesianos.triana.dam.Miarma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiarmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
